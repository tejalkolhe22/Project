package com.edu.vehicle.error;
public class VehicleNotFoundException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehicleNotFoundException(String s) {
		super(s);
	}
}

